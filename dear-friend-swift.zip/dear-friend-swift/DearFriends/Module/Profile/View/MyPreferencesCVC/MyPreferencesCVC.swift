//
//  MyPreferencesCVC.swift
//  DearFriends
//
//  Created by Harsh Doshi on 15/09/23.
//

import UIKit

class MyPreferencesCVC: UICollectionViewCell {

    @IBOutlet weak var imgBG: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var vwMain: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
