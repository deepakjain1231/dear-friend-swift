//
//  FavouriteCVC.swift
//  DearFriends
//
//  Created by Himanshu Visroliya on 17/05/23.
//

import UIKit

class FavouriteCVC: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
