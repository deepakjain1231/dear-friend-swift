//
//  ViewAllCVC.swift
//  DearFriends
//
//  Created by Himanshu Visroliya on 19/05/23.
//

import UIKit

class ViewAllCVC: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
