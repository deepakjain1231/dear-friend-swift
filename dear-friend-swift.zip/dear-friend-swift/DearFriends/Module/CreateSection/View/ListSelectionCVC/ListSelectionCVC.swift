//
//  ListSelectionCVC.swift
//  DearFriends
//
//  Created by Harsh Doshi on 19/10/23.
//

import UIKit

class ListSelectionCVC: UICollectionViewCell {

    @IBOutlet weak var vwMain: UIView!
    @IBOutlet weak var lbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
