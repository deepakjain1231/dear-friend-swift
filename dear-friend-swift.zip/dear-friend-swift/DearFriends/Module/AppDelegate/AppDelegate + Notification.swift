//
//  AppDelegate + Notification.swift
//  Covantex
//
//  Created by Covantex LLC on 17/10/23.
//  Copyright © 2023 Covantex LLC. All rights reserved.
//

import UIKit
import Foundation
import UserNotifications
import Firebase
import FirebaseMessaging

	//When app in foreground, This method will triggered, We can manage alert, badge, sound here
	// The method will be called on the delegate only if the application is in the foreground. If the method is not implemented or the handler is not called in a timely manner then the notification will not be presented. The application can choose to have the notification presented as a sound, badge, alert and/or in the notification list. This decision should be based on whether the information in the notification is otherwise visible to the user.
extension AppDelegate: UNUserNotificationCenterDelegate {
	func userNotificationCenter(_ center: UNUserNotificationCenter,
								willPresent notification: UNNotification,
								withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions)
								-> Void) {
		let userInfo = notification.request.content.userInfo as NSDictionary
        print(#function)
        print(userInfo)

        if #available(iOS 14.0, *) {
            completionHandler([.list, .banner, .sound, .badge])
        } else {
            completionHandler([.alert, .sound, .badge])
        }
	}

		//When app in background or killed or sunspended or inactive, This method will triggered.
		// The method will be called on the delegate when the user responded to the notification by opening the application, dismissing the notification or choosing a UNNotificationAction. The delegate must be set before the application returns from application:didFinishLaunchingWithOptions:.
	func userNotificationCenter(_ center: UNUserNotificationCenter,
								didReceive response: UNNotificationResponse,
								withCompletionHandler completionHandler: @escaping () -> Void) {
		let userInfo = response.notification.request.content.userInfo
        print(#function)
        print(userInfo)
		completionHandler()
	}
	
		//Applications with the "fetch" background mode may be given opportunities to fetch updated content in the background or when it is convenient for the system. This method will be called in these situations. You should call the fetchCompletionHandler as soon as you're finished performing that operation
	func application(_ application: UIApplication,
					 didReceiveRemoteNotification userInfo: [AnyHashable: Any],
					 fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult)
					 -> Void) {
		let userInfo = userInfo as! [String : Any]
        // run important background tasks
        print(#function)
        print(userInfo)
		completionHandler(.newData)
	}
}

extension AppDelegate {
	func application(
		_ application: UIApplication,
		didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
				//        Messaging.messaging().apnsToken = deviceToken

			let tokenParts = deviceToken.map { data in String(format: "%02.2hhx", data) }
			let token = tokenParts.joined()
			print("Device Token: \(token)")

            Messaging.messaging().delegate = self
            Messaging.messaging().apnsToken = deviceToken
		}

	func application(
		_ application: UIApplication,
		didFailToRegisterForRemoteNotificationsWithError error: Error) {
            print(#function)
            print(error)

//			AppLog.log("Failed to register for notifications: \(error.localizedDescription)")
//			SDKUserDefault.save("", for: DefaultKey.DeviceToken.value)
		}

	func registerForPushNotifications() {
        
        FirebaseApp.configure()

        main_thread {
            UIApplication.shared.registerForRemoteNotifications()
            UNUserNotificationCenter.current().delegate = self
            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
                if let error = error {
                    print("Permission error: \(error.localizedDescription)")
                } else if granted {
                    DispatchQueue.main.async {
                        UIApplication.shared.registerForRemoteNotifications()
                    }
                }
            }
        }
	}

	func resetRemoteNotification() {
		main_thread {
			UIApplication.shared.applicationIconBadgeNumber = 0
			let center = UNUserNotificationCenter.current()
			center.removeAllDeliveredNotifications()
			center.removeAllPendingNotificationRequests()
		}
	}
}
