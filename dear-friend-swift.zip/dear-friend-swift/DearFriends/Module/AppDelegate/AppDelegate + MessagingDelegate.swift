//
//  NotificaiotnFile.swift
//  Pheli FM
//
//  Created by Jigar Khatri on 7/02/24.
//

import UIKit
import Foundation
import FirebaseCore
import FirebaseMessaging
import SwiftyJSON


//extension AppDelegate : UNUserNotificationCenterDelegate {
//    
//    func setFireBase_Notificaiton(application: UIApplication){
//        //FIREBASE CONFIGURE
//#if ENGCOBO
//print("test")
//#else
//print("now")
//#endif
//        FirebaseApp.configure()
//        Messaging.messaging().delegate = self
//
//        main_thread {
//            //Push Notification Register
//            UNUserNotificationCenter.current().delegate = self
//            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) {
//                (granted, error) in
//                if let error = error {
//                    debugPrint("[AppDelegate] requestAuthorization error: \(error.localizedDescription)")
//                    return
//                }
//                UNUserNotificationCenter.current().getNotificationSettings(completionHandler: { settings in
//                    if settings.authorizationStatus != .authorized {
//                        return
//                    }
//                    DispatchQueue.main.async(execute: {
//                        UIApplication.shared.registerForRemoteNotifications()
//                    })
//                })
//                //Parse errors and track state
//            }
//            application.registerForRemoteNotifications()
//        }
//    }
//}



//MARK: - Push notification
extension AppDelegate : MessagingDelegate {
    func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String?) {
        self.deviceToken = fcmToken ?? ""
        print("FCM TOKEN -> \(self.deviceToken)")
        
        //CEHCK TOKEN IS VALIDE
        Messaging.messaging().token { token, error in
          if let error = error {
            print("Error fetching FCM registration token: \(error)")
          } else if let token = token {
            print("Remote FCM registration token: \(token)")
          }
        }
        
        
//        //SET FIREBASE TOPIC
//        var strTopic : String = ""
//        strTopic = "DearFriends_123123"
//        print("TOPIC -> \(strTopic)")
//
////#if DEBUG
////        strTopic = "mangomolo_\(Application.userID)_\(strUUID)"
////        UIPasteboard.general.string = strTopic
////#endif
//        Messaging.messaging().subscribe(toTopic: strTopic) { error in
//            print("Subscribed to weather topic")
//            print(strTopic)
//        }
    }
    

//    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
//        
//        if let userInfo = userInfo as? [String: Any] {
//            let jsonUserInfo = JSON(userInfo)
//            print("JSON didReceiveRemoteNotification", jsonUserInfo)
//                        
//            let state = UIApplication.shared.applicationState
//            if state == .background {
//                self.handlePush(json: jsonUserInfo)
//            }
//        }
//        completionHandler(UIBackgroundFetchResult.newData)
//    }
    
        
    /*
    // MARK: - UNUserNotificationCenter Delegate // >= iOS 10
    //Called when a notification is delivered to a foreground app.
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        
        if let userInfo = notification.request.content.userInfo as? [String : Any] {
            let jsonUserInfo = JSON(userInfo)
            print("JSON willPresent", jsonUserInfo)
            
//            let payload = jsonUserInfo["payload"]
//            let data = payload["data"]
//            
//            let pushType = data["push_type"].intValue
//            let object_id = data["object_id"].stringValue
//            
//            appDelegate.titleText = data["push_title"].stringValue
//            appDelegate.descText = data["push_message"].stringValue
//            
//            guard let topVc = UIApplication.topViewController2() else { return }
//            
//            if let notiVc = topVc as? NotificationsVC {
//                notiVc.setupUI()
//            }
//            
//            if pushType == 1 {
//                if let msgVC = topVc as? ChatMessageVC {
//                    completionHandler([.badge])
//                }
//                
//            } else if pushType == 6 {
//                if let pushVC = topVc as? NotificationsVC {
//                    pushVC.customID = object_id
//                    pushVC.setupUI()
//                }
//                completionHandler([.list, .badge, .sound])
//                
//            } else {
//                self.handlePush(json: jsonUserInfo)
//                completionHandler([.list, .badge, .sound])
//            }
        }
    }
     */
    
    func handlePush(json: JSON) {
        
        let payload = json["payload"]
        let data = payload["data"]
        
        let pushType = data["push_type"].intValue
        let object_id = data["object_id"].stringValue
        
        appDelegate.titleText = data["push_title"].stringValue
        appDelegate.descText = data["push_message"].stringValue
        
        guard let topVc = UIApplication.topViewController2() else { return }
        
        if pushType == 1 {
            if let msgVC = UIApplication.topViewController2() as? ChatMessageVC {
                if msgVC.customID == object_id {
                    msgVC.getChatHistory(isShowloader: false)
                }
            }
            
        } else if pushType == 2 {
            if let msgVC = UIApplication.topViewController2() as? MyReminderVC {
                msgVC.dataBind()
            }
            
        } else if pushType == 5 {
            if let msgVC = UIApplication.topViewController2() as? BookingDetailsVC {
                if msgVC.id ==  object_id {
                    msgVC.getDetails()
                }
            }
            
        } else if pushType == 6 {
            if let pushVC = topVc as? NotificationsVC {
                pushVC.setupUI()
                
            } else {
                self.setNotiRoot(customID: object_id)
            }
        }
    }
    
    /*
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        
        let userInfo = response.notification.request.content.userInfo as NSDictionary
        let jsonUserInfo = JSON(userInfo)
        print("JSON didReceive", userInfo)
        
        let payload = jsonUserInfo["payload"]
        let data = payload["data"]
        
        let pushType = data["push_type"].intValue
        let object_id = data["object_id"].stringValue
                
        appDelegate.titleText = data["push_title"].stringValue
        appDelegate.descText = data["push_message"].stringValue
        
        if pushType == 1 {
            self.setMessageRoot(customID: object_id)
            
        } else if pushType == 2 {
            self.setReminderRoot()
            
        } else if pushType == 5 {
            self.setBookingRoot(id: object_id)
            
        } else if pushType == 6 {
            self.setNotiRoot(customID: object_id)
        }
    }
     */
}

