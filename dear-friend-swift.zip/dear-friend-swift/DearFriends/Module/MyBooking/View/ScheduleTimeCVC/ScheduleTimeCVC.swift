//
//  ScheduleTimeCVC.swift
//  DearFriends
//
//  Created by Harsh Doshi on 15/09/23.
//

import UIKit

class ScheduleTimeCVC: UICollectionViewCell {

    @IBOutlet weak var vwMain: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
