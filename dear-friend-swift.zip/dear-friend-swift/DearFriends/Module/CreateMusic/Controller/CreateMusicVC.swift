//
//  CreateMusicVC.swift
//  DearFriends
//
//  Created by Harsh Doshi on 06/09/23.
//

import UIKit

class CreateMusicVC: UIViewController {
    
    // MARK: - OUTLETS
    
    // MARK: - VARIABLES
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setupUI()
    }
    
    // MARK: - Other Functions
    
    func setupUI() {
        
    }
    
    // MARK: - Button Actions
}

// MARK: - TableView Methods

// MARK: - CollectionView Methods
