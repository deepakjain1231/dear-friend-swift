//
//  WebServiceKey.swift
//  KYT
//
//  Created by admin on 21/11/19.
//  Copyright © 2019 Kavin Soni. All rights reserved.
//

import Foundation

let kiOS                = "ios"
let kPushToken          = "push_token"
let kToken              = "token"
let kDeviceType         = "device_type"
let kDeviceID           = "device_id"
let kid                 = "id"
let kName               = "name"
let kFirstName          = "first_name"
let kLastName           = "last_name"
let kemail              = "email"
let kPassword           = "password"
let kConfirmPassword    = "cpassword"
let kCountryCode        = "country_code"
let kEventNotification  = "event_notification"
let kMobile             = "mobile"
let kReferralCode       = "referral_code"
let kProfileImage       = "profile_image"
let kSocialProvider     = "social_provider"
let kSocialID           = "social_id"
let kType               = "type"
let kValue              = "value"
let user_id             = "user_id"
let kVersion            = "version"
let kApple              = "apple"
let kKAKO               = "kako"
let kNAVER              = "naver"

let kCateringID         = "catering_id"
let kQTY                = "qty"
let kSearch             = "search"
let kMessage            = "message"

let kOffset             = "offset"
let kLimit              = "limit"
let kPostId             = "post_id"


