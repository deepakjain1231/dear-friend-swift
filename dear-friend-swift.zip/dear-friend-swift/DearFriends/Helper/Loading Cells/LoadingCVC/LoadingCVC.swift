//
//  LoadingCVC.swift
//  DearFriends
//
//  Created by Himanshu Visroliya on 02/06/23.
//

import UIKit

class LoadingCVC: UICollectionViewCell {

    @IBOutlet weak var loader: UIActivityIndicatorView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
