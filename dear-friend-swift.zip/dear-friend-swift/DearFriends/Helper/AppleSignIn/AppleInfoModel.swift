//
//  File.swift
//  YesChef
//
//  Created by Hitesh Surani on 13/02/20.
//  Copyright © 2020 Hitesh Surani. All rights reserved.
//

import Foundation


struct AppleInfoModel {
    let userid:String
    let email:String
    let firstName:String
    let lastName:String
    let fullName:String
}
